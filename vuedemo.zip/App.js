;(function () {
    const template = `<div id="#app">
                            <order-list/>
                        </div>`

    window.App = {
        template,
        methods: {
        },
        components: {
            OrderList
        } 
    }
})()